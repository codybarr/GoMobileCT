module.exports = {
  secret: '4LlY2zPSnk9HIXsioFCSaOkJepFKOiVq5MMqODmN',
  port: process.env.PORT || 3000,
  database: process.env.DB || 'mongodb://localhost/gomobilect'
};
